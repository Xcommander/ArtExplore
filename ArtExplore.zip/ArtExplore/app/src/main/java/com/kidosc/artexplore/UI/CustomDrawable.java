package com.kidosc.artexplore.UI;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;

/**
 * Created by jason.xu on 2019/3/25.
 */
public class CustomDrawable extends Drawable {

    @Override
    public void draw(@androidx.annotation.NonNull Canvas canvas) {

    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(@androidx.annotation.Nullable ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return 0;
    }
}
